module.exports = {
    giphyApiKey: process.env.GIPHY_API_KEY || 'dc6zaTOxFJmzC',
    ownerNumber: process.env.OWNER_NUMBER || '923216582841',
    botName: 'GHOST 𝗠𝗗 𝗕𝗢𝗧',
    ownerName: 'HAMZA '
};
